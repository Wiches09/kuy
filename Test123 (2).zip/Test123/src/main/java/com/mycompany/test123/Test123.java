package com.mycompany.test123;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.websocket.ClientEndpoint;
import jakarta.websocket.ContainerProvider;
import jakarta.websocket.OnClose;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.WebSocketContainer;
import java.io.IOException;
import java.net.URI;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author helld
 */
@ClientEndpoint
public class Test123 {

    private Session session;
    private String username;

    public static void main(String[] args) throws Exception {
        WebSocketContainer container = ContainerProvider.getWebSocketContainer();
        Session session = container.connectToServer(Test123.class, new URI("ws://localhost:6000"));
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
    }

    @OnOpen
    public void onOpen(Session session) throws Exception {
        Player player = null;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your username.");
        username = sc.nextLine();
        String message = "{\"handler\":\"auth\",\"username\":\"" + username + "\"}";
        System.out.println(message);
        session.getBasicRemote().sendText(message);

    }

    @OnMessage
    public void onMessage(String message) throws IOException {
        System.out.println("helloweold");
//        ObjectMapper mapper = new ObjectMapper();
//        WebsocketRes res = mapper.readValue(message, WebsocketRes.class);
        HandlerCheck checker = new HandlerCheck(message);

//        System.out.println("Received message: " + res.getContent());
//        //System.out.println("Received message: " + message);.
//        String status = res.getStatus();
//        if (status.equals("ok")) {
//            System.out.println("yes");
//        } else {
//            System.out.println("Your Username is already in used, please enter new username.");
//            Scanner sc2 = new Scanner(System.in);
//            String str = sc2.nextLine();
//        }public void onMessage(String message) {
        // Handle incoming messages
//        if ("OK".equals(res.getStatus())){
//            System.out.println("1");
//        }
//        else{
//            System.out.print("2");
//        }
    }

    public void connect() throws Exception {
        WebSocketContainer container = ContainerProvider.getWebSocketContainer();
        session = container.connectToServer(this, new URI("ws://localhost:8080/chat"));

    }

    @OnClose
    public void onClose(Session Session) {

    }

}
