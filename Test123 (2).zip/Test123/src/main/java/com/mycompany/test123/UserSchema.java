/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.test123;

/**
 *
 * @author helld
 */
public class UserSchema {
    private String username;
    private String connectID;
    private int g_scr;
    private String c_card[];
    private String c_tCard[];
    private boolean st_ready;
    private boolean st_stand;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getConnectID() {
        return connectID;
    }

    public void setConnectID(String connectID) {
        this.connectID = connectID;
    }

    public int getG_scr() {
        return g_scr;
    }

    public void setG_scr(int g_scr) {
        this.g_scr = g_scr;
    }

    public String[] getC_card() {
        return c_card;
    }

    public void setC_card(String[] c_card) {
        this.c_card = c_card;
    }

    public String[] getC_tCard() {
        return c_tCard;
    }

    public void setC_tCard(String[] c_tCard) {
        this.c_tCard = c_tCard;
    }

    public boolean isSt_ready() {
        return st_ready;
    }

    public void setSt_ready(boolean st_ready) {
        this.st_ready = st_ready;
    }

    public boolean isSt_stand() {
        return st_stand;
    }

    public void setSt_stand(boolean st_stand) {
        this.st_stand = st_stand;
    }
    
    
    
    
    
}
