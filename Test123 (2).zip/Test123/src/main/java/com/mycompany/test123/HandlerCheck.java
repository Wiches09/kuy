/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.test123;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;

/**
 *
 * @author helld
 */
public class HandlerCheck {

    private String st1 = "CONNECTION_AUTHROIZED";
    private String st2 = "READY_STATE";
    private String st3 = "UPDATE_CARDS";
    private String st4 = "HIT_EVENT";

    
// WITHOUT TRY CATCH WHEN MAPPING
    public HandlerCheck(String event) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        WebsocketRes res = mapper.readValue(event, WebsocketRes.class);
        System.out.println(res.getHandler());

        System.out.println(res.getStatus());
        System.out.println(res.getHandler());
        System.out.println(res.getContent().getUsername());
        System.out.println(res.getContent().getConnectionID());
        
        boolean con1 = res.getHandler().equals(st1);
        boolean con2 = res.getHandler().equals(st2);
        boolean con3 = res.getHandler().equals(st3);
        boolean con4 = res.getHandler().equals(st4);

//        if (con1 || con2 || con3 || con4) {
//            WebsocketRes res2 = mapper.readValue(res.getContent(), WebsocketRes.class);
//        }
        if (res.getHandler().equals("CONNECTION_SUCCESS")) {
            System.out.println("CONNECTION SUCCESS!!");
        } else if (res.getHandler().equals("CONNECTION_AUTHROIZED")) {
            if ("OK".equals(res.getStatus())) {
                System.out.println("1");
                
//                String connectionId = res.getContent().getConnectionID();
                System.out.println(connectionId);
            } else {
                System.out.print("2");
            }
        }
    }
}

    
    
    // WITH TRY CATCH WHEN MAPPING
//        public HandlerCheck(String event) throws IOException {
//        ObjectMapper mapper = new ObjectMapper();
//        try {
//            WebsocketRes res = mapper.readValue(event, WebsocketRes.class);
//
//            System.out.println(res.getHandler());
//
//            System.out.println(res.getStatus());
//            System.out.println(res.getHandler());
//            System.out.println(res.getContent().getUsername());
//            System.out.println(res.getContent().getConnectionID());
//
//            boolean con1 = res.getHandler().equals(st1);
//            boolean con2 = res.getHandler().equals(st2);
//            boolean con3 = res.getHandler().equals(st3);
//            boolean con4 = res.getHandler().equals(st4);
//
////        if (con1 || con2 || con3 || con4) {
////            WebsocketRes res2 = mapper.readValue(res.getContent(), WebsocketRes.class);
////        }
//            if (res.getHandler().equals("CONNECTION_SUCCESS")) {
//                System.out.println("CONNECTION SUCCESS!!");
//            } else if (res.getHandler().equals("CONNECTION_AUTHROIZED")) {
//                if ("OK".equals(res.getStatus())) {
//                    System.out.println("1");
//                    String connectionId = res.getContent().getConnectionID();
//                    System.out.println(connectionId);
//                } else {
//                    System.out.print("2");
//                }
//            }
//        } catch (IOException e) {
//            System.out.println("failed");
//        }
//
//    }
//}