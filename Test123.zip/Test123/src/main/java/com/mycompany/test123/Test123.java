
package com.mycompany.test123;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.websocket.ClientEndpoint;
import jakarta.websocket.ContainerProvider;
import jakarta.websocket.OnMessage;
import jakarta.websocket.Session;
import jakarta.websocket.WebSocketContainer;
import java.io.IOException;
import java.net.URI;
import java.util.Scanner;

/**
 *
 * @author helld
 */
@ClientEndpoint
public class Test123 {

    public static void main(String[] args) throws Exception {
        WebSocketContainer container = ContainerProvider.getWebSocketContainer();
        Session session = container.connectToServer(Test123.class, new URI("ws://localhost:6000"));
        //session.getBasicRemote().sendText("Hello, server!");
        
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
    }

    @OnMessage
    public void onMessage(String message) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        WebsocketRes res = mapper.readValue(message, WebsocketRes.class);
        System.out.println("Received message: " + res.getContent());
    }
}
