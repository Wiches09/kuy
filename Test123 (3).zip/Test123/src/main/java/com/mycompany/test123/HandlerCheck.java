
package com.mycompany.test123;

import org.json.JSONObject;

/**
 *
 * @author helld
 */
public class HandlerCheck {
    
    public HandlerCheck(String message){
        // create object to turn json to string
        JSONObject jobj = new JSONObject(message);
        JSONObject n_content = null; // to use if content is a object
        
        System.out.println("JSON Object: "+ jobj); 

        Object checker = jobj.get("content"); // to check if content is a object

        // convert to string
        String handler = jobj.getString("handler");
        String status = jobj.getString("status");
//        String error = jobj.getString("error");
//        String description = jobj.getString("description");
  
        // check content
        if (checker instanceof String) {
            System.out.println("c_Word");
        } else {
            System.out.println("c_Obj");
            n_content = jobj.getJSONObject("content");
            System.out.println("new content: " + n_content);
        }
        
        System.out.println(handler);
        System.out.println();
        
        
        // doing case stuff
        switch (handler) {
            case "CONNECTION_AUTHROIZED" -> {
                
            }
            case "READY_STATE" -> {
                
            }
            case "UPDATE_CARDS" -> {
                
            }
            case "HIT_EVENT" -> {
                
            }
            default -> {
                
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
}